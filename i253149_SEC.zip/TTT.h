#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include <SFML/Audio.hpp>

using namespace std;

class TicTacToe 
{

	sf::RenderWindow* gameWindow ;
	sf::RectangleShape cells[3][3];
	sf::RectangleShape lines[4];
	sf::Text mark[3][3];
	sf::Font font;
	sf::Text turnText;
	sf::Text player1Score;
	sf::Text player2Score;
	sf::Text gameOverText;

	sf::Color xcolor;
	sf::Color oColor;
	sf::Color gridColor;
	sf::Color backgroundColor;

	float marks[3][3];
	bool markG[3][3];

	char player1[20];
	char player2[20];

	char grid[3][3];

	int score1;
	int score2;

	bool win1;
	bool win2;
	bool gameOver;
	bool scoreSaved;

	int currentPlayer;



	sf::SoundBuffer pointsSoundBuffer;
	sf::Sound pointsSound;
	sf::SoundBuffer gameOverBuffer;
	sf::Sound gameOverSound;

public:
	TicTacToe(char p1[20], char p2[20]);

	

	void initGame();
	void handleEvents();
	void handleCellClick(int ,int );
	bool checkDraw();
	void update();
	void render();
	void drawUI();
	void updateTurnText();
	void centerText(sf::Text& text, float x, float y);
	void resetGame();
	bool checkWin1();
	bool checkWin2();
	void run();
	void leaderBoard();

};
