#pragma once

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include <iostream>
using namespace std;
class Pong
{

	char player1name[20];
	char player2name[20];


	static const int screenwidth = 900;
	static const int screenheight = 700;
	static const int gridSize = 20;


	static const int cellSize = 30;
	static const int winScore = 5;


	struct Paddle
	{
		float x, y;
		float width, height;
		float speed;
		int score;

	};
	struct Ball
	{
		float x, y;
		float radius;
		float baseSpeed;
		float dx, dy; // dx = horizontal change, dy = vertical change
	};
	
	Ball ball;
	Paddle paddle1;
	Paddle paddle2;
	

	bool gameOver;
	bool p1win;
	bool p2win;
	bool serve;
	bool scoreSaved;
	


	sf::RenderWindow* gameWindow;
	sf::RectangleShape background;
	sf::RectangleShape paddle1shape;
	sf::RectangleShape paddle2shape;
	sf::CircleShape ballCell;

	//text
	sf::Font font;
	sf::Text player1NameText;
	sf::Text player2NameText;
	sf::Text player1ScoreText;
	sf::Text player2ScoreText;
	sf::Text gameOverText;
	sf::Text winnerText;
	sf::Text serveText;
	sf::Text instructionsText;

	//timing
	sf::Clock clock;
	const float BALL_SPEED = 5.0f;         
	const float PADDLE_SPEED = 6.0f; 
	sf::Clock deltaClock;
	


	//colors
	sf::Color paddle1Color;
	sf::Color paddle2Color;
	sf::Color ballColor;
	sf::Color backgroundColor;

	//sounds 

	sf::SoundBuffer paddleHitBuffer;
	sf::Sound paddleHitSound;
	sf::SoundBuffer wallHitBuffer;
	sf::Sound wallHitSound;
	sf::SoundBuffer scoreBuffer;
	sf::Sound scoreSound;
	sf::SoundBuffer gameOverBuffer;
	sf::Sound gameOverSound;


public:
	Pong(char name1[20], char name2[20]);
	void init();
	void serveBall();
	void checkCollisions();
	void drawUI();
	void run();
	void update();
	void handleEvents();
	void render();
	void reset();
	void updateTexts();
	void centerText(sf::Text& text, float x, float y);
	void leaderBoard();

};
