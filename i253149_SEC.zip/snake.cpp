#include "snake.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
using namespace std;

Snake::Snake(char p1[20], char p2[20])
{
	snakeWindow = new sf::RenderWindow(sf::VideoMode(900, 700), "Snake");

	for (int i = 0; i < 20; i++)
	{
		player1name[i] = p1[i];
		player2name[i] = p2[i];
	}

	srand(time(nullptr));

	//colors

	snake1Color = sf::Color::Magenta;
	snake2Color = sf::Color::Blue;
	foodColor = sf::Color :: Red;
	backgroundColor = sf::Color(68, 161, 148);
	gridColor = sf::Color(70,70,70);
	score1Color =  sf::Color::Magenta;
	score2Color = sf::Color::Blue;
	deadColor = sf::Color(100, 100, 100);
	if (!font.loadFromFile("assets/fonts/Roboto-Bold.ttf"))
	{
		cout << "could not load fonts";
	}

	if (eatSoundBuffer.loadFromFile("assets/sounds/eatsound.wav")) {
		eatSound.setBuffer(eatSoundBuffer);
	}
	

	if (gameOverBuffer.loadFromFile("assets/sounds/gameover.wav")) {
		gameOverSound.setBuffer(gameOverBuffer);
	}



	initGame();
	//reset();
	reset();

}
void Snake::run()
{
	while (snakeWindow->isOpen())
	{
		handleEvents();
		update();
		render();
	}
}
void Snake::reset()
{
	score1 = 0;
	score2 = 0;
	isAlive1 = true;
	isAlive2 = true;
	gameOver = false;
	p1Won = false;
	p2Won = false;

	scoreSaved = false;
	s1Length = 3;
	s2Length = 3;
	s1Dir = 0;
	s2Dir = 2;
	snake1[0] = { 5,10 };
	snake1[1] = { 4,10 };
	snake1[2] = { 3,10 };

	snake2[0] = { 14,10 };
	snake2[1] = { 15,10 };
	snake2[2] = { 16,10 };

	crashReason = 0;

	placeFood();

	gameOverAlpha =  0.0f;
	moveClock.restart();

}

void Snake::initGame()
{
	float gridWidth = gridSize * cellSize;
	float gridHeight = gridSize * cellSize;

	float X = 140;
	float Y = 60;

	// grid cells
	for (int i = 0; i < gridSize; i++) 
	{
		for (int j = 0; j < gridSize; j++)
		{
			cells[i][j].setSize(sf::Vector2f(cellSize - 2, cellSize - 2));
			cells[i][j].setPosition(X + j * cellSize + 1, Y + i * cellSize + 1);
			cells[i][j].setFillColor(sf::Color(40, 40, 50));
		}
	}

	// snake cells
	for (int i = 0; i < 400; i++) 
	{
		s1Cell[i].setSize(sf::Vector2f(cellSize - 4, cellSize - 4));
		s2Cell[i].setSize(sf::Vector2f(cellSize - 4, cellSize - 4));
	}

	foodcell.setSize(sf::Vector2f(cellSize - 5, cellSize - 5));
	foodcell.setFillColor(foodColor);



	p1Name.setFont(font);
	p1Name.setFillColor(score1Color);
	p1Name.setCharacterSize(23);

	p2Name.setFont(font);
	p2Name.setFillColor(score2Color);
	p2Name.setCharacterSize(23);

	score1Text.setFont(font);
	score1Text.setFillColor(score1Color);
	score1Text.setCharacterSize(20);

	score2Text.setFont(font);
	score2Text.setFillColor(score2Color);
	score2Text.setCharacterSize(20);

	gameOverText.setFont(font);
	gameOverText.setFillColor(sf::Color::Yellow);
	gameOverText.setCharacterSize(40);
	gameOverText.setString("GAME OVER");

	instructions.setFont(font);
	instructions.setFillColor(sf::Color::Cyan);
	instructions.setCharacterSize(20);
	instructions.setString("Player 1: \nW(up) A(left) D(right) S(down)\nPlayer 2:\nI(up) J(left) L(right) K(down)");

	updateTexts();

}

void Snake::placeFood()
{
	bool canPlace = true;
	do {
		food.x = rand() % gridSize;
		food.y = rand() % gridSize;

		bool onSnake1 = !collision1(food.x, food.y);
		bool onSnake2 = !collision2(food.x, food.y);
		if (onSnake1 || onSnake2) canPlace = false;

	} while (!canPlace);
	

}

bool Snake::collision1(int x, int y) const
{
	for (int i = 0; i < s1Length; i++)
	{
		if (x == snake1[i].x && y == snake1[i].y) return false;
	}

	return true;
}
bool Snake::collision2(int x, int y) const
{
	for (int i = 0; i < s2Length; i++)
	{
		if (x == snake2[i].x && y == snake2[i].y) return false;
	}
	return true;
}

bool Snake::checkCollision(int headX, int headY, int player) {


	if (headX < 0 || headX >= gridSize || headY < 0 || headY >= gridSize) {
		crashReason = 0;  
		return true;
	}

	if (player == 0) {  
		
		for (int i = 1; i < s1Length; i++) {
			if (snake1[i].x == headX && snake1[i].y == headY) {
				gameOverSound.play();
				crashReason = 1;  
				return true;
			}
		}
		// Other snake
		if (isAlive2)
		{
			for (int i = 0; i < s2Length; i++) {
				if (snake2[i].x == headX && snake2[i].y == headY) {
					gameOverSound.play();
					crashReason = 2;  // Other snake
					return true;
				}
			}
		}
		
	}
	else {  // Player 2
		// Own body
		for (int i = 1; i < s2Length; i++) {
			if (snake2[i].x == headX && snake2[i].y == headY) {
				gameOverSound.play();
				crashReason = 1;
				return true;
			}
		}
		// Other snake

		if (isAlive1)
		{
			for (int i = 0; i < s1Length; i++) {
				if (snake1[i].x == headX && snake1[i].y == headY) {
					gameOverSound.play();
					crashReason = 2;
					return true;
				}
			}
		}
		
	}

	return false;
}

void Snake::moveSnake(int player)
{
	if (player == 0 && !isAlive1) return;
	if (player == 1 && !isAlive2) return;
	if (player == 0)
	{
		int newHeadx = snake1[0].x;
		int newHeady = snake1[0].y;

		switch (s1Dir)
		{
			case 0: newHeadx++; break;
			case 1: newHeady++; break;
			case 2:newHeadx--; break;
			case 3: newHeady--; break;
		}

		bool ateFood = (food.x == newHeadx && food.y == newHeady);
		

		if (checkCollision(newHeadx, newHeady, 0))
		{
			isAlive1 = false;
			gameOverSound.play();
			//return;
		}

		for (int i = s1Length - 1; i > 0; i--) 
		{
			snake1[i] = snake1[i - 1];        // tail moves where previous body was
		}

		snake1[0] = { newHeadx, newHeady };

		if (ateFood)
		{
			s1Length++;
			snake1[s1Length - 1] = snake1[s1Length - 2];
			score1 += 10;
			eatSound.play();
			placeFood();
		}

	}

	else
	{

		int newHeadx = snake2[0].x;
		int newHeady = snake2[0].y;

		switch (s2Dir)
		{
		case 0: newHeadx++; break;
		case 1: newHeady++; break;
		case 2:newHeadx--; break;
		case 3: newHeady--; break;
		}

		bool ateFood = (food.x == newHeadx && food.y == newHeady);


		if (checkCollision(newHeadx, newHeady, 1))
		{
			isAlive2 = false;
			//return;
		}

		for (int i = s2Length - 1; i > 0; i--)
		{
			snake2[i] = snake2[i - 1];        // tail moves where previous body was
		}

		snake2[0] = { newHeadx, newHeady };

		if (ateFood)
		{
			s2Length++;
			snake2[s2Length - 1] = snake2[s2Length - 2];
			score2 += 10;
			eatSound.play();
			placeFood();
		}

	}
	if (!isAlive1 && !isAlive2)
	{
		return;
	}
}

void Snake::checkWinCondition() {
	// Check for head-on collision
	
	//if (isAlive1 && isAlive2) 
	{
		if (snake1[0].x == snake2[0].x && snake1[0].y == snake2[0].y) {
			isAlive1 = false;
			isAlive2 = false;
			crashReason = 3;
		}
	}

	if (score1 > score2) {
		p1Won = true;
	}
	else if (score2 > score1) {
		p2Won = true;
	}
	else {
		p1Won = true;
		p2Won = true;
	}

	if (!isAlive1 && !isAlive2) gameOver = true;

	
}
void Snake::update() {

	if (!snakeWindow) return;
	if (gameOver) {
		if (gameOverAlpha < 200) gameOverAlpha += 5;
		return;
	}
	
	// Move snakes at regular intervals
	if (moveClock.getElapsedTime().asSeconds() > delay) {
		// Store old head positions for collision detection
		int oldSnake1HeadX = snake1[0].x;
		int oldSnake1HeadY = snake1[0].y;
		int oldSnake2HeadX = snake2[0].x;
		int oldSnake2HeadY = snake2[0].y;

		// Move both snakes
		moveSnake(0);
		moveSnake(1);

		// Check win condition
		checkWinCondition();

		moveClock.restart();
	}

	// Animate food
	if (foodGrowing) {
		foodScale += 0.02f;
		if (foodScale >= 1.3f) foodGrowing = false;
	}
	else {
		foodScale -= 0.02f;
		if (foodScale <= 0.7f) foodGrowing = true;
	}

	// Update text
	updateTexts();
}
void Snake::updateTexts() {
	char buffer[50];

	p1Name.setString(player1name);
	p2Name.setString(player2name);

	sprintf_s(buffer, "Score: %d", score1);
	score1Text.setString(buffer);

	sprintf_s(buffer, "Score: %d", score2);
	score2Text.setString(buffer);
	
	p1Name.setPosition(50, 10);
	score1Text.setPosition(50, 40);
	p2Name.setPosition(750, 10);
	score2Text.setPosition(750, 40);
	instructions.setPosition(50, 750);
}

void Snake::handleEvents()
{
	if (!snakeWindow) return;
	sf::Event event;

	while (snakeWindow->pollEvent(event))   // if any event happens put it inside event
	{
		if (event.type == sf::Event::Closed) 
		{
			snakeWindow->close();
		}

		if (event.type == sf::Event::KeyPressed)
		{
			if (event.key.code == sf::Keyboard::R) {
				reset();
				return;
			}
			if (event.key.code == sf::Keyboard::Escape) {
				snakeWindow->close(); 
				return;
			}

			if (!gameOver)
			{
				//player 1 controls
				if (event.key.code == sf::Keyboard::W)
				{
					if (s1Dir != 1) s1Dir = 3;
				}
				else if (event.key.code == sf::Keyboard::D)
				{ 
					if (s1Dir != 2) s1Dir = 0;
				}
				else if (event.key.code == sf::Keyboard::S) 
				{
					if (s1Dir != 3) s1Dir = 1;
				}
				else if (event.key.code == sf::Keyboard::A) 
				{
					if (s1Dir != 0) s1Dir = 2;
				}
				
				//player 2 controls

				if (event.key.code == sf::Keyboard::I)
				{
					if (s2Dir != 1) s2Dir = 3;
				}
				else if (event.key.code == sf::Keyboard::L)
				{
					if (s2Dir != 2) s2Dir = 0;
				}
				else if (event.key.code == sf::Keyboard::K)
				{
					if (s2Dir != 3) s2Dir = 1;
				}
				else if (event.key.code == sf::Keyboard::J)
				{
					if (s2Dir != 0) s2Dir = 2;
				}
			}

		}
	}
}

void Snake::drawGrid()
{
	float gridWidth = gridSize * cellSize;
	float gridHeight = gridSize * cellSize;

	float X = 140;
	float Y = 60;
	

	for (int i = 0; i < gridSize; i++) {
		for (int j = 0; j < gridSize; j++) {
			cells[i][j].setPosition(X + j * cellSize + 1,Y + i * cellSize + 1);
			snakeWindow->draw(cells[i][j]);
		}
	}

	// grid lines
	for (int i = 0; i <= gridSize; i++) {
		// Vertical lines

		sf::RectangleShape vLine(sf::Vector2f(2, gridHeight));
		vLine.setFillColor(gridColor);
		vLine.setPosition(X + i * cellSize - 1, Y);
		snakeWindow->draw(vLine);

		// Horizontal lines
		sf::RectangleShape hLine(sf::Vector2f(gridWidth, 2));
		hLine.setFillColor(gridColor);
		hLine.setPosition(X, Y + i * cellSize - 1);
		snakeWindow->draw(hLine);
	}
}

void Snake::drawSnakes()
{
	float gridWidth = gridSize * cellSize;
	float gridHeight = gridSize * cellSize;

	float X = 140;
	float Y = 60;


	//snake 1
	for (int i = 0; i < s1Length; i++)
	{
		s1Cell[i].setPosition(X + snake1[i].x * cellSize + 2, Y + snake1[i].y * cellSize + 2);

		if (isAlive1)
		{
			s1Cell[i].setFillColor(snake1Color);
		}
		else
		{
			s1Cell[i].setFillColor(deadColor);
		}

		s1Cell[i].setSize(sf::Vector2f(cellSize - 4, cellSize - 4));

		snakeWindow->draw(s1Cell[i]);
	}


	//snake 2
	for (int i = 0; i < s2Length; i++)
	{
		s2Cell[i].setPosition(X + snake2[i].x * cellSize + 2, Y + snake2[i].y * cellSize + 2);
		if (isAlive2)
		{
			s2Cell[i].setFillColor(snake2Color);
		}
		else
		{
			s2Cell[i].setFillColor(deadColor);
		}
		s2Cell[i].setSize(sf::Vector2f(cellSize - 4, cellSize - 4));
		snakeWindow->draw(s2Cell[i]);
	}
}


void Snake::drawUI() {
	// info
	snakeWindow->draw(p1Name);
	snakeWindow->draw(score1Text);
	snakeWindow->draw(p2Name);
	snakeWindow->draw(score2Text);
	snakeWindow->draw(instructions);

	
	
}

void Snake::render()
{
	if (!snakeWindow) return;
	
	float gridWidth = gridSize * cellSize;
	float gridHeight = gridSize * cellSize;
	
	float X = 140;
	float Y = 60;
	snakeWindow->clear(backgroundColor);

	

	drawGrid();

	foodcell.setScale(foodScale, foodScale);
	foodcell.setPosition(X + food.x * cellSize + (cellSize / 2) - (cellSize - 8) / 2 * foodScale,
		Y + food.y * cellSize + (cellSize / 2) - (cellSize - 8) / 2 * foodScale);
	snakeWindow->draw(foodcell);

	drawSnakes();
	drawUI();

	if (gameOver) {
		leaderBoard();
		scoreSaved = true;
		drawGameOver();
	}
	snakeWindow->display();
}


void Snake::drawGameOver() {
	sf::RectangleShape overlay;
	overlay.setSize(sf::Vector2f(900,700));
	overlay.setFillColor(sf::Color(0, 0, 0, static_cast<sf::Uint8>(gameOverAlpha)));
	snakeWindow->draw(overlay);
	gameOverSound.play();

	if (gameOverAlpha > 150) {
		gameOverText.setCharacterSize(80);
		gameOverText.setFillColor(sf::Color(255, 255, 255)); // White pops more
		centerText(gameOverText, 450, 200);
		snakeWindow->draw(gameOverText);

		// 3. Winner Announcement
		sf::Text winnerDisplay;
		winnerDisplay.setFont(font);
		winnerDisplay.setCharacterSize(40);
		winnerDisplay.setFillColor(sf::Color::Yellow);

		if (score1 > score2)
			winnerDisplay.setString(string(player1name) + " WINS!");
		else if (score2 > score1)
			winnerDisplay.setString(string(player2name) + " WINS!");
		else
			winnerDisplay.setString("IT'S A DRAW!");

		centerText(winnerDisplay, 450, 300);
		snakeWindow->draw(winnerDisplay);

		// 4. Final Scores
		score1Text.setCharacterSize(30);
		score2Text.setCharacterSize(30);
		centerText(score1Text, 450, 380);
		centerText(score2Text, 450, 420);
		snakeWindow->draw(score1Text);
		snakeWindow->draw(score2Text);


	}
}

void Snake::centerText(sf::Text& text, float x, float y) {
	sf::FloatRect textRect = text.getLocalBounds();
	text.setOrigin(textRect.left + textRect.width / 2.0f,
		textRect.top + textRect.height / 2.0f);
	text.setPosition(x, y);
}

void Snake::leaderBoard()
{
	if (gameOver && !scoreSaved)
	{
		ofstream file("score.txt",  ios::app);
		file << "Snake: ";
		if (score1 > score2)
		{
			file << player1name << " Won Score: " << score1<<endl;
		}
		else if(score2>score1) 
		{
			file << player2name << " Won Score: " << score2<<endl;
		}
		else
		{
			file << "Draw ";
			file << player1name << " score: " << score1<<endl;
			file << player2name << " score: " << score2<<endl;
		}
		file.close();                 

	}

}