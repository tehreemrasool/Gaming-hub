#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Snake.h"
#include "Pong.h"
#include "TTT.h"
#include "leaderboard.h"


class GameHub {
private:
    sf::RenderWindow window;
    sf::Font font;
    sf::Event event;

 
    enum GameState {
        MAIN_MENU,
        NAME_INPUT,
        PLAYING_GAME,
        LEADERBOARD,
        EXIT
    };
    GameState currentState;
    int selectedMenuItem;    // 0: Snake, 1: Pong, 2: TicTacToe, 3: Leaderboard, 4: Exit
    int selectedGame;         // Which game was chosen (0-2)

    
    static const int totalMenu = 5;
    sf::Text menuTexts[totalMenu];
    sf::RectangleShape menuBackgrounds[totalMenu];

    
    char player1Name[20];
    char player2Name[20];
    int inputStage;           // 0: entering player1, 1: entering player2
    sf::Text inputPromptText;
    sf::Text inputDisplayText;
    char currentInput[20]; 
    int gameIndex;
    
    Snake* snakeGame;
    Pong* pongGame;
    TicTacToe* tttGame;
    Leaderboard* board;

    // leaderboard
    //sf::Text leaderboardTitle;
    //sf::Text leaderboardText;
    //sf::Text backInstruction;

   
    sf::RectangleShape background;
    sf::Color backgroundColor;
    sf::Color textColors;

public:
    GameHub();
    ~GameHub();

    void run(); 
    void initWindow();
    void initFont();
    void initMenu();
    void initGames();
    //void initLeaderboardDisplay();

    void handleMainMenuEvents();
    void handleNameInputEvents();
    void handleLeaderboardEvents();

    void renderMainMenu();
    void renderNameInput();
    void renderLeaderboard();

    void startGame(int gameIndex);
    void returnToMainMenu();
    //void updateLeaderboardDisplay();

    void centerText(sf::Text& text, float x, float y);
};