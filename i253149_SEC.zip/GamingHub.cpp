#include <cstdlib>
#include<iostream>
#include <fstream>
using namespace std;
#include "GamingHub.h"
#include <cstring>
#include <sstream>


GameHub::GameHub()
{
    currentState = MAIN_MENU;
    selectedMenuItem = 0;
    selectedGame = 0;
    inputStage = 0;
    gameIndex = -1;
    backgroundColor = sf::Color(68, 161, 148);
    initWindow();
    initFont();
    initMenu();
    initGames();
    //initLeaderboardDisplay();
    player1Name[0] = '\0';
    player2Name[0] = '\0';
    currentInput[0] = '\0';
}

GameHub::~GameHub() {
    delete snakeGame;
    delete pongGame;
    delete tttGame;
}

void GameHub::initWindow() {
    window.create(sf::VideoMode(900, 700), "Gaming Hub", sf::Style::Close | sf::Style::Titlebar);
    window.setFramerateLimit(60);
}

void GameHub::initFont() {
    if (!font.loadFromFile("assets/fonts/Roboto-Bold.ttf")) {
        printf("Error loading font\n"); return;
    }
}

void GameHub::initMenu() {
    const char* items[totalMenu] = {
        "Snake",
        "Pong",
        "Tic Tac Toe",
        "Leaderboard",
        "Exit"
    };

    float yPos = 200.0f;
    for (int i = 0; i < totalMenu; i++) {
        menuTexts[i].setFont(font);
        menuTexts[i].setString(items[i]);
        menuTexts[i].setCharacterSize(40);
        menuTexts[i].setFillColor(sf::Color::White);

        sf::FloatRect bounds = menuTexts[i].getLocalBounds();
        menuTexts[i].setOrigin(bounds.width / 2, bounds.height / 2);
        menuTexts[i].setPosition(450, yPos);

        menuBackgrounds[i].setSize(sf::Vector2f(300, 50));
        menuBackgrounds[i].setFillColor(sf::Color(50, 50, 50, 200));
        menuBackgrounds[i].setOrigin(150, 25);
        menuBackgrounds[i].setPosition(450, yPos);

        yPos += 70;
    }

   
    background.setSize(sf::Vector2f(900, 700));
    background.setFillColor(backgroundColor);
}

void GameHub::initGames() {
    
    snakeGame = nullptr;
    pongGame = nullptr;
    tttGame = nullptr;
    board = nullptr;
}



void GameHub::centerText(sf::Text& text, float x, float y) {
    sf::FloatRect bounds = text.getLocalBounds();
    text.setOrigin(bounds.left + bounds.width / 2, bounds.top + bounds.height / 2);
    text.setPosition(x, y);
}

void GameHub::run() {
    while (window.isOpen() && currentState != EXIT) {
        
        switch (currentState) {
        case MAIN_MENU:
            handleMainMenuEvents();
            break;
        case NAME_INPUT:
            handleNameInputEvents();
            break;
        case PLAYING_GAME:
            if (gameIndex == 0 && snakeGame)
            {
                snakeGame->handleEvents();
                snakeGame->update();
                snakeGame->render();
            }
            else if (gameIndex == 1 && pongGame)
            {
                pongGame->handleEvents();
                pongGame->update();
                pongGame->render();
            }
            else if (gameIndex == 2 && tttGame)
            {
                tttGame->handleEvents();
                tttGame->update();
                tttGame->render();
            }
            break;
       
        case LEADERBOARD:
            board->render(); break;
        default:
            break;
        }

        window.clear();
        window.draw(background);

        switch (currentState) {
        case MAIN_MENU:
            renderMainMenu();
            break;
        case NAME_INPUT:
            renderNameInput();
            break;
        case PLAYING_GAME:
            break;
        //case LEADERBOARD:
        //    renderLeaderboard();
        //    break;
        default:
            break;
        }

        window.display();
    }
}

void GameHub::handleMainMenuEvents() {
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }

        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Up) {
                selectedMenuItem = (selectedMenuItem - 1 + totalMenu) % totalMenu;
            }
            else if (event.key.code == sf::Keyboard::Down) {
                selectedMenuItem = (selectedMenuItem + 1) % totalMenu;
            }
            else if (event.key.code == sf::Keyboard::Enter) {
                if (selectedMenuItem == 4) { // Exit
                    currentState = EXIT;
                }

                else if (selectedMenuItem == 3) {
                    startGame(3); 
                }
                
                else { // Game selected
                    selectedGame = selectedMenuItem;
                    inputStage = 0;
                    
                    player1Name[0] = '\0';
                    player2Name[0] = '\0';
                    currentState = NAME_INPUT;
                }
            }
        }

        // Mouse hover
        if (event.type == sf::Event::MouseMoved) {
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            sf::Vector2f mousePosF(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
            for (int i = 0; i < totalMenu; i++) {
                if (menuBackgrounds[i].getGlobalBounds().contains(mousePosF)) {
                    selectedMenuItem = i;
                    break;
                }
            }
        }

        // Mouse click
        if (event.type == sf::Event::MouseButtonPressed) {
            if (event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                sf::Vector2f mousePosF(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
                for (int i = 0; i < totalMenu; i++) {
                    if (menuBackgrounds[i].getGlobalBounds().contains(mousePosF)) {
                        if (i == 4) {
                            currentState = EXIT;
                        }
                        else if (i == 3) 
                        {
                            startGame(3);
                        }
                        

                        else {
                            selectedGame = i;
                            inputStage = 0;
                            
                            player1Name[0] = '\0';
                            player2Name[0] = '\0';
                            currentState = NAME_INPUT;
                        }
                        break;
                    }
                }
            }
        }
    }
}

void GameHub::renderMainMenu() {
   
    sf::Text title;
    title.setFont(font);
    title.setString("GAMING HUB");
    title.setCharacterSize(80);
    title.setFillColor(sf::Color(242, 96, 118));
    centerText(title, 450, 100);
    window.draw(title);

   
    for (int i = 0; i < totalMenu; i++) {
        if (i == selectedMenuItem) {
            menuBackgrounds[i].setFillColor(sf::Color(100, 100, 200, 200));
            menuTexts[i].setFillColor(sf::Color(242, 96, 118));
        }
        else {
            menuBackgrounds[i].setFillColor(sf::Color(50, 50, 50, 200));
            menuTexts[i].setFillColor(sf::Color(244, 240, 228));
        }
        window.draw(menuBackgrounds[i]);
        window.draw(menuTexts[i]);
    }

    // Instructions
    sf::Text instr;
    instr.setFont(font);
    instr.setCharacterSize(16);
    instr.setFillColor(sf::Color(180, 180, 180));
    centerText(instr, 450, 650);
    window.draw(instr);
}

void GameHub::handleNameInputEvents() {
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }

        if (event.type == sf::Event::KeyPressed) {
           
            if (event.key.code == sf::Keyboard::Escape) {
                currentState = MAIN_MENU;
                currentInput[0] = '\0'; 
                return;
            }

            
            if (event.key.code == sf::Keyboard::BackSpace) {
                size_t len = strlen(currentInput);
                if (len > 0) {
                    currentInput[len - 1] = '\0';
                }
            }

            
            else if (event.key.code == sf::Keyboard::Enter) {
                if (strlen(currentInput) > 0) 
                { 
                    if (inputStage == 0) {
                        strncpy_s(player1Name, currentInput, 19);
                        player1Name[19] = '\0'; 
                        currentInput[0] = '\0'; 
                        inputStage = 1;
                    }
                    else {
                        strncpy_s(player2Name, currentInput, 19);
                        player2Name[19] = '\0';
                        startGame(selectedGame);
                    }
                }
            }

            
            else if (strlen(currentInput) < 18) 
            { 
                char typedChar = '\0';

               
                if (event.key.code >= sf::Keyboard::A && event.key.code <= sf::Keyboard::Z) {
                    
                    if (event.key.shift)
                        typedChar = 'A' + (event.key.code - sf::Keyboard::A);
                    else
                        typedChar = 'a' + (event.key.code - sf::Keyboard::A);
                }
                else if (event.key.code == sf::Keyboard::Space) {
                    typedChar = ' ';
                }
                if (typedChar != '\0') {
                    size_t len = strlen(currentInput);
                    currentInput[len] = typedChar;
                    currentInput[len + 1] = '\0'; 
                }
            }
        }
    }
}

void GameHub::renderNameInput() {
    sf::Text prompt;

    sf::RectangleShape inputBox(sf::Vector2f(500.0f, 80.0f));
    inputBox.setFillColor(sf::Color(0, 0, 0, 80)); 
    inputBox.setOutlineThickness(3.0f);
    inputBox.setOutlineColor(sf::Color(242, 96, 118)); 
    inputBox.setOrigin(250.0f, 40.0f); 
    inputBox.setPosition(450.0f, 350.0f);



    prompt.setFont(font);
    prompt.setCharacterSize(30);
    prompt.setFillColor(sf::Color::White);

    if (inputStage == 0) {
        prompt.setString("Enter Player 1 name:");
    }
    else {
        prompt.setString("Enter Player 2 name:");
    }
    centerText(prompt, 450, 250);


    

   
    sf::Text inputText;
    inputText.setFont(font);
    inputText.setCharacterSize(40);
    inputText.setFillColor(sf::Color(242, 96, 118));
    inputText.setString(currentInput);

    centerText(inputText, 450, 350);

    string displayedInput = currentInput;
    if (static_cast<int>(clock() / 500) % 2 == 0) { // Blinking effect
        displayedInput += "_";
    }
    inputText.setString(displayedInput);
    centerText(inputText, 450, 345);

    window.draw(prompt);
    window.draw(inputText);

    // Instructions
    sf::Text instr;
    instr.setFont(font);
    instr.setString("Type name, press Enter to confirm, ESC to cancel");
    instr.setCharacterSize(18);
    instr.setFillColor(sf::Color(242, 96, 118));
    centerText(instr, 450, 500);
    window.draw(instr);
}

void GameHub::handleLeaderboardEvents() {
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }
        if (event.type == sf::Event::KeyPressed) {
            if (event.key.code == sf::Keyboard::Escape) {
                currentState = MAIN_MENU;
            }
        }
        if (event.type == sf::Event::MouseButtonPressed) {
            currentState = MAIN_MENU;
        }
    }
}




void GameHub::startGame(int gameIndex) {
   
    this->gameIndex = gameIndex;

    switch (gameIndex) {
    case 0: // Snake
        if (snakeGame) delete snakeGame;
        snakeGame = new Snake(player1Name, player2Name);
        snakeGame->initGame();
        snakeGame->run();
        break;
    case 1: // Pong
        if (pongGame) delete pongGame;
        pongGame = new Pong(player1Name, player2Name);
        pongGame->init();
        pongGame->run();
        break;
    case 2: // TicTacToe
        if (tttGame) delete tttGame;
        tttGame = new TicTacToe(player1Name, player2Name);
        tttGame->initGame();
        tttGame->run();
        break;

    case 3: // Leaderboard
    { 
        window.setVisible(false);
        Leaderboard board;
        board.run();
        window.setVisible(true);
    }
    break;
    }
    

    currentState = PLAYING_GAME;

    window.setVisible(true);      
    currentState = MAIN_MENU;     
    inputStage = 0;               
    selectedMenuItem = 0;
}

void GameHub::returnToMainMenu() {
    //currentGame = nullptr;
    currentState = MAIN_MENU;
    selectedMenuItem = 0;
}
void GameHub::renderLeaderboard()
{
}