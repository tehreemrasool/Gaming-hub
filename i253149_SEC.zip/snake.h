#include <SFML/Graphics.hpp>
#include <iostream>
#include <SFML/Audio.hpp>

using namespace std;

class Snake
{

	char player1name[20];
	int score1;
	char player2name[20];
	int score2;

	bool scoreSaved;

	struct Segment
	{
		int x, y;
	};

	//snake 1

	int s1Length;
	int s1Dir;      // 0 right, 1 up, 2 left, 3 down
	Segment snake1[400];
	bool isAlive1;

	//snake 2

	int s2Length;
	int s2Dir;      // 0 right, 1 up, 2 left, 3 down
	Segment snake2[400];
	bool isAlive2;

	Segment food;
	static const int gridSize = 20;
	static const int cellSize = 30;

	bool gameOver;
	bool p1Won;
	bool p2Won;
	int crashReason;     // 0 wall, 1 own body, 2 other body

	sf::RenderWindow* snakeWindow;
	sf::RectangleShape cells[gridSize][gridSize] ;
	sf::RectangleShape background;
	sf::RectangleShape lines[gridSize+1];
	sf::RectangleShape s1Cell[400];
	sf::RectangleShape s2Cell[400];
	sf::RectangleShape foodcell;

	//text
	sf::Font font;
	sf::Text p1Name;
	sf::Text p2Name;
	sf::Text gameOverText;
	sf::Text score1Text;
	sf::Text score2Text;
	sf::Text instructions;


	//colors
	sf::Color snake1Color;
	sf::Color deadColor;
	sf::Color snake2Color;
	sf::Color foodColor;
	sf::Color backgroundColor;
	sf::Color gridColor;
	sf::Color score1Color;
	sf::Color score2Color;

	sf::Clock moveClock;
	const float delay = 0.15f;



	//Animations
	float foodScale;
	bool foodGrowing;
	float gameOverAlpha;
	bool fadingIn;


	//sounds
	sf::SoundBuffer eatSoundBuffer;
	sf::Sound eatSound;
	sf::SoundBuffer deadSoundBuffer;
	sf::Sound deadSound;
	sf::SoundBuffer gameOverBuffer;
	sf::Sound gameOverSound;

public:

	Snake(char p1[20], char p2[20]);
	void reset();
	void initGame();
	void placeFood();
	bool collision1(int, int) const;
	bool collision2(int, int)const;
	bool checkCollision(int, int, int);

	void moveSnake(int);

	void checkWinCondition();
	void update();
	void updateTexts();
	void handleEvents();
	void drawGrid();
	void drawSnakes();
	void drawUI();
	void render();
	void drawGameOver();
	void run();
	void centerText(sf::Text& text, float x, float y);
	void leaderBoard();
};

