#include <iostream>
#include <fstream>
#include <string>
#include "leaderboard.h"
using namespace std;

Leaderboard::Leaderboard()
{
	gameWindow = new sf::RenderWindow(sf::VideoMode(900, 700), "Leaderboard");


	scoresLoaded = 0;

	backgroundColor = sf::Color(68, 161, 148);
	nameColor = sf::Color::Red;
	scoreColor = sf::Color(242, 96, 118);

	if (!font.loadFromFile("assets/fonts/Roboto-Bold.ttf"))
	{
		cout << "could not load fonts";
	}

	init();
}

void Leaderboard::init()
{
	nameText.setFont(font);
	nameText.setFillColor(nameColor);
	nameText.setCharacterSize(23);

}

void Leaderboard::write()
{
	ifstream file("score.txt");

	scoresLoaded = 0; 

	if (file.is_open()) {
		while (scoresLoaded < maxScores && getline(file, scores[scoresLoaded])) {
			scoresLoaded++;
		}
		file.close();
	}
}

void Leaderboard::run() {
	write();
	while (gameWindow->isOpen()) {
		sf::Event ev;
		while (gameWindow->pollEvent(ev)) {
			if (ev.type == sf::Event::Closed) {
				gameWindow->close();
			}
			if (ev.type == sf::Event::KeyPressed) {
				if (ev.key.code == sf::Keyboard::Escape) {
					gameWindow->close(); 
				}
			}
		}
		render(); 
	}
}

void Leaderboard::render() {
	gameWindow->clear(backgroundColor);

	sf::Text title("LEADERBOARD", font, 50);
	title.setFillColor(sf::Color::Yellow);
	centerText(title, 450, 60);
	gameWindow->draw(title);

	//ifstream file("score.txt");
	//string line;
	float yOffset = 150.0f;

	//while (getline(file, line))
	//{
	//	centerText(nameText, 450, yOffset);

	//	nameText.setString(line);
	//	gameWindow->draw(nameText);
	//	yOffset += 50.0f;

	//}

	
	for (int i = 0; i < scoresLoaded; i++) {
		nameText.setString(scores[i]);
		centerText(nameText, 450, yOffset);
		gameWindow->draw(nameText);

		yOffset += 50.0f; 
	}
	sf::Text backMsg("Press ESC to return", font, 20);
	backMsg.setFillColor(sf::Color::White);
	centerText(backMsg, 450, 650);
	gameWindow->draw(backMsg);

	gameWindow->display();
}

void Leaderboard::centerText(sf::Text& text, float x, float y) {
	sf::FloatRect rect = text.getLocalBounds();
	text.setOrigin(rect.left + rect.width / 2.f, rect.top + rect.height / 2.f);
	text.setPosition(x, y);
}
void Leaderboard::saveScore(const char* name, int score) {
	ofstream file("score.txt", ios::app);
	if (file.is_open()) {
		file << name << " : " << score << endl;
		file.close();
	}
}