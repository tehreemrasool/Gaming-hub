#include "TTT.h"
#include <SFML/Graphics.hpp>
#include <fstream>
#include <iostream>
using namespace std;


void TicTacToe::run()
{
	while (gameWindow->isOpen())
	{
		handleEvents();
		update();
		render();
	}
}
TicTacToe::TicTacToe(char p1[20], char p2[20]) 
{

	gameWindow = new sf::RenderWindow(sf::VideoMode(900, 700), "Tic Tac Toe");

	for (int i = 0; i < 20; i++)
	{
		player1[i] = p1[i];
		player2[i] = p2[i];
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			grid[i][j] = ' ';
		}
	}
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			marks[i][j] = 0.0f;  // Start invisible
			markG[i][j] = true;
		}
	}
	scoreSaved = false;

	score1 = 0;
	score2 = 0;
	gameOver = false;
	win1 = false;
	win2 = false;
	currentPlayer = 0;


	xcolor = sf::Color::Red;
	oColor = sf::Color::Blue;
	gridColor = sf::Color(242, 96, 118);
	backgroundColor = sf::Color(68, 161, 148);

	//add animation here

	if (!font.loadFromFile("assets/fonts/Roboto-Bold.ttf"))
	{
		cout << "could not load fonts";
	}

	if (pointsSoundBuffer.loadFromFile("assets/sounds/points.wav")) {
		pointsSound.setBuffer(pointsSoundBuffer);
	}
	if (gameOverBuffer.loadFromFile("assets/sounds/gameover.wav")) {
		gameOverSound.setBuffer(gameOverBuffer);
	}
	initGame();
}

//initialize game window

void TicTacToe::initGame()
{
	if (!gameWindow)return;

	float boxSize = 150.0f;
	float width = 450.0f;  
	float height = 450.0f;
	float X = 225.0f;      
	float Y = 125.0f;

	for (int i = 0; i < 4; i++)
	{
		lines[i].setFillColor(gridColor);
	}

	//vertical lines
	lines[0].setSize(sf::Vector2f(5, height));
	lines[0].setPosition(X + boxSize - 2.5, Y);

	lines[1].setSize(sf::Vector2f(5, height));
	lines[1].setPosition(X + boxSize * 2 - 2.5f, Y);

	//horizontal lines
	lines[2].setSize(sf::Vector2f(width, 5));
	lines[2].setPosition(X ,Y+ boxSize - 2.5f);

	lines[3].setSize(sf::Vector2f(width, 5));
	lines[3].setPosition(X ,Y+ boxSize*2 - 2.5f);

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cells[i][j].setSize(sf::Vector2f(boxSize - 10, boxSize - 10));
			cells[i][j].setPosition(X + j * boxSize + 5, Y + i * boxSize + 5);
			cells[i][j].setFillColor(sf::Color(255, 255, 255, 0));

			mark[i][j].setFont(font);
			mark[i][j].setCharacterSize(100);
			mark[i][j].setStyle(sf::Text::Bold);
			mark[i][j].setString(" ");
			sf::FloatRect textRect = mark[i][j].getLocalBounds();
			mark[i][j].setOrigin(textRect.left + textRect.width / 2.0f,
				textRect.top + textRect.height / 2.0f);
			mark[i][j].setPosition(X + j * boxSize + boxSize / 2.0f,Y + i * boxSize + boxSize -5 / 2.0f);

		}

	}


	turnText.setFont(font);
	turnText.setCharacterSize(30);
	turnText.setFillColor(sf::Color::Yellow);

	player1Score.setFont(font);
	player1Score.setCharacterSize(20);
	player1Score.setFillColor(oColor);

	player2Score.setFont(font);
	player2Score.setCharacterSize(20);
	player2Score.setFillColor(xcolor);

	gameOverText.setFont(font);
	gameOverText.setCharacterSize(30);
	gameOverText.setFillColor(sf::Color::Green);

	updateTurnText();

}

void TicTacToe::handleEvents()
{
	if (!gameWindow) return;

	sf::Event event;

	while (gameWindow->pollEvent(event))
	{
		if (event.type == sf::Event::Closed)
		{
			gameWindow->close();
		}
		if (event.key.code == sf::Keyboard::Escape) {
			gameWindow->close();
			return;
		}

		if (event.type == sf::Event::MouseButtonPressed && !gameOver)
		{
			if (event.mouseButton.button == sf::Mouse::Left)
			{
				sf::Vector2i mousePos = sf::Mouse::getPosition(*gameWindow);
				sf::Vector2f mousePosF(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));    //get mouse position
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 3; j++)
					{
						if (cells[i][j].getGlobalBounds().contains(mousePosF))   // checking if mouse is inside the cell
						{
							handleCellClick(i, j);
							return;
						}


					}
				}
			}
		}


		if (event.type == sf::Event::KeyPressed) {
			if (event.key.code == sf::Keyboard::R) {
				resetGame();


			}
		}
	}
}

void TicTacToe::handleCellClick(int row,int col)
{
	
	if (grid[row][col] != ' ' || gameOver) return; 

	//player 1
	if (currentPlayer == 0) {
		grid[row][col] = 'O';  
		mark[row][col].setString("O");
		pointsSound.play();
		mark[row][col].setFillColor(oColor);

	
		win1 = checkWin1();
		if (win1) {
			score1++;
			gameOver = true;
		}
	}
	//player 2
	else {
		grid[row][col] = 'X';  
		mark[row][col].setString("X");
		pointsSound.play();
		mark[row][col].setFillColor(xcolor);

		
		win2 = checkWin2();
		if (win2) {
			score2++;
			gameOver = true;
		}
	}

	
	marks[row][col] = 0.0f;
	markG[row][col] = true;

	if (!gameOver) 
	{
		
		bool draw = checkDraw();
		if (draw) {
			gameOverSound.play();
			gameOver = true;
			gameOverText.setString("DRAW!");
			centerText(gameOverText, 400, 100);
			
			leaderBoard();
			scoreSaved = true;

		}
		else {
			currentPlayer = (currentPlayer == 0) ? 1 : 0;   //switch player
		}
	}
	else {
		leaderBoard();
		scoreSaved = true;
		if (win1) {
			gameOverSound.play();
			char winnerMsg[50] = "PLAYER 1 WINS!";
			gameOverText.setString(winnerMsg);
		}
		else if (win2) {
			gameOverSound.play();
			char winnerMsg[50] = "PLAYER 2 WINS!";
			gameOverText.setString(winnerMsg);
		}
		centerText(gameOverText, 400, 100);
	}

	updateTurnText();
}



bool TicTacToe::checkDraw() {
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (grid[i][j] == ' ') {
				return false; 
			}
		}
	}
	return true; 
}

void TicTacToe::resetGame() {
	// clear grod
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			grid[i][j] = ' ';
			mark[i][j].setString("");
			marks[i][j] = 0.0f;
		}
	}

	// Reset game state
	win1 = false;
	win2 = false;
	gameOver = false;
	currentPlayer = 0;  // Player 1 starts

	updateTurnText();
}

void TicTacToe::update() {
	
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (grid[i][j] != ' ') {
				 //Animate scale
				if (marks[i][j] < 1.0f) {
					marks[i][j] += 0.1f;
					if (marks[i][j] > 1.0f) marks[i][j] = 1.0f;
				}
				mark[i][j].setScale(marks[i][j], marks[i][j]);
			}
		}
	}

	player1Score.setString(std::string("Player 1: ") + std::to_string(score1));
	player2Score.setString(std::string("Player 2: ") + std::to_string(score2));

	
	player1Score.setPosition(50, 50);
	player2Score.setPosition(650, 50);
}
void TicTacToe::render() {
	if (!gameWindow || !gameWindow->isOpen()) return;
	// background

	gameWindow->clear(backgroundColor);

	sf::RectangleShape background;
	background.setSize(sf::Vector2f(
		static_cast<float>(gameWindow->getSize().x),
		static_cast<float>(gameWindow->getSize().y)));
	//background.setSize(sf::Vector2f(gameWindow->getSize().x, gameWindow->getSize().y));
	background.setFillColor(backgroundColor);
	gameWindow->draw(background);



	// grid lines
	for (int i = 0; i < 4; i++) {
		gameWindow->draw(lines[i]);
	}
	

	// cells
	sf::Vector2i mousePos = sf::Mouse::getPosition(*gameWindow);
	sf::Vector2f mousePosF(static_cast<float>(mousePos.x),
		static_cast<float>(mousePos.y));

	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (grid[i][j] == ' ') {  // Only highlight empty cells
				if (cells[i][j].getGlobalBounds().contains(mousePosF) && !gameOver) {
					cells[i][j].setOutlineColor(sf::Color(200, 200, 200, 200));
				}
				else {
					cells[i][j].setOutlineColor(sf::Color(100, 100, 100, 0));
				}
			}
			else {
				cells[i][j].setOutlineColor(sf::Color(100, 100, 100, 0));
			}
			gameWindow->draw(cells[i][j]);
		}
	}

	//marks

	
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (grid[i][j] != ' ') {
				gameWindow->draw(mark[i][j]);
			}
		}
	}

	// Draw UI
	drawUI();
	gameWindow->display();

}

void TicTacToe::drawUI() {
	// turn indicator
	

	sf::RectangleShape scoreBar(sf::Vector2f(900, 80));
	scoreBar.setFillColor(sf::Color(0, 0, 0, 100));
	gameWindow->draw(scoreBar);

	gameWindow->draw(player1Score);
	gameWindow->draw(player2Score);
	if (!gameOver) {
		gameWindow->draw(turnText);
	}

	if (gameOver) {
		sf::RectangleShape overlay(sf::Vector2f(900, 700));
		overlay.setFillColor(sf::Color(0, 0, 0, 150)); // Darken the screen
		gameWindow->draw(overlay);

		
		gameOverText.setCharacterSize(70); // Make it huge
		gameOverText.setOutlineThickness(3);
		gameOverText.setOutlineColor(sf::Color::Black);

		if (win1) gameOverText.setFillColor(oColor);
		else if (win2) gameOverText.setFillColor(xcolor);
		else gameOverText.setFillColor(sf::Color::White); 

		centerText(gameOverText, 450, 300);
		gameWindow->draw(gameOverText);

		
		sf::Text resetText("PRESS [R] TO REMATCH  |  [ESC] FOR MENU", font, 22);
		resetText.setFillColor(sf::Color(200, 200, 200));
		centerText(resetText, 450, 380);
		gameWindow->draw(resetText);
	}
}


void TicTacToe::updateTurnText() {
	if (currentPlayer == 0) {
		char turnMsg[50];
		// Use your player1 name
		strcpy_s(turnMsg, sizeof(turnMsg), player1);
		strcat_s(turnMsg, sizeof(turnMsg), "'s turn (O)");
		turnText.setString(turnMsg);
		turnText.setFillColor(oColor);
	}
	else {
		char turnMsg[50];
		strcpy_s(turnMsg, sizeof(turnMsg), player2);
		strcat_s(turnMsg, sizeof(turnMsg), "'s turn (X)");
		turnText.setString(turnMsg);
		turnText.setFillColor(xcolor);
	}
	centerText(turnText, 450, 620);
}
bool TicTacToe::checkWin1()
{
	bool w1 = false;
	for (int i = 0; i < 3; i++)
	{
		bool isTrue = true;
		for (int j = 0; j < 3; j++)
		{
			if (grid[i][j] != 'O')
			{
				isTrue = false;
				break;
			}
	
		}
		if (isTrue)return true;


	}
	for (int i = 0; i < 3; i++)
	{
		bool isTrue = true;
		for (int j = 0; j < 3; j++)
		{
			if (grid[j][i] != 'O')
			{
				isTrue = false;
				break;
			}
		}
		if (isTrue)return true;

	}
	bool isTrue = true;

	for (int i = 0; i < 3; i++)
	{
		
			if (grid[i][i] != 'O')
			{
				isTrue = false;
				break;
			}
	}
	if (isTrue)return true;


	 isTrue = true;

	for (int i = 0; i < 3; i++)
	{
		if( grid[i][3 - i - 1]!= 'O') 
		{
			isTrue = false;
			break;
		}
	}
	if (isTrue)return true;
	return false;

}
bool TicTacToe::checkWin2()
{
	bool w2 = false;
	for (int i = 0; i < 3; i++)
	{
		bool isTrue = true;
		for (int j = 0; j < 3; j++)
		{
			if (grid[i][j] != 'X')
			{
				isTrue = false;
				break;
			}

		}
		if (isTrue) return true;


	}
	for (int i = 0; i < 3; i++)
	{
		bool isTrue = true;
		for (int j = 0; j < 3; j++)
		{
			if (grid[j][i] != 'X')
			{
				isTrue = false;
				break;
			}
		}
		if (isTrue)return true;

	}
	bool isTrue = true;

	for (int i = 0; i < 3; i++)
	{

		if (grid[i][i] != 'X')
		{
			isTrue = false;
			break;
		}
	}
	if (isTrue)return true;


	 isTrue = true;

	for (int i = 0; i < 3; i++)
	{
		if (grid[i][3 - i - 1] != 'X')
		{
			isTrue = false;
			break;
		}
	}
	if (isTrue) return true;

	return false;
}

void TicTacToe::centerText(sf::Text& text, float x, float y) {
	sf::FloatRect rect = text.getLocalBounds();
	text.setOrigin(rect.left + rect.width / 2.f, rect.top + rect.height / 2.f);
	text.setPosition(x, y);
}

void TicTacToe::leaderBoard()
{
	if (gameOver && !scoreSaved)
	{
		ofstream file("score.txt", ios::app);
		file << "Tic Tac Toe:  ";
		if (score1 > score2)
		{

			file << player1 << " Won " << endl;
		}
		else if (score2 > score1)
		{
			file << player2 << " Won "<<endl;
		}
		else
		{
			file << "Draw\t";
			file << player1 <<endl;
			file << player2 <<endl;
		}
		file.close();

	}
}

