#include "pong.h"
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
using namespace std;


void Pong::run()
{
	while (gameWindow->isOpen())
	{
		handleEvents();
		update();
		gameWindow->clear(); 
		render();
		gameWindow->display(); 
	}
}

Pong::Pong(char name1[20], char name2[20])
{
	for (int i = 0; i < 20; i++)
			{
				player1name[i] = name1[i];
				player2name[i] = name2[i];
			}
	srand(time(nullptr));

	paddle1Color = sf::Color(242, 96, 118);
	paddle2Color = sf::Color(242, 96, 118);
	ballColor = sf::Color(242, 96, 118);
	backgroundColor = sf::Color(68, 161, 148);
	gameWindow = new sf::RenderWindow(sf::VideoMode(900, 700), "Pong");
	gameWindow->setFramerateLimit(60); 


	// Paddle dimensions
	paddle1.width = 15.0f;
	paddle1.height = 100.0f;
	paddle1.speed = 7.0f;
	paddle2.width = 15.0f;
	paddle2.height = 100.0f;
	paddle2.speed = 7.0f;

	// Ball properties
	ball.radius = 8.0f;
	ball.baseSpeed = 5.0f;

	init();
	reset();


	if (!font.loadFromFile("assets/fonts/Roboto-Bold.ttf")) 
	{
		printf("Could not load font!\n");
	}


	 //Load sounds
	if (paddleHitBuffer.loadFromFile("assets/sounds/ballhit.wav")) {
		paddleHitSound.setBuffer(paddleHitBuffer);
	}
	if (wallHitBuffer.loadFromFile("assets/sounds/ballhit.wav")) {
		wallHitSound.setBuffer(wallHitBuffer);
	}
	if (scoreBuffer.loadFromFile("assets/sounds/points.wav")) {
		scoreSound.setBuffer(scoreBuffer);
	}
	if (gameOverBuffer.loadFromFile("assets/sounds/gameover.wav")) {
		gameOverSound.setBuffer(gameOverBuffer);
	}

}
void Pong::reset()
{
	paddle1.x = 50.0f;
	paddle1.y = screenheight/ 2.0f - paddle1.height / 2;
	paddle1.score = 0;
	scoreSaved = false;
	paddle2.x = screenwidth - 50.0f - paddle2.width;
	paddle2.y = screenheight / 2.0f - paddle2.height / 2;
	paddle2.score = 0;

	ball.x = screenwidth / 2;
	ball.y = screenheight / 2;
	ball.dx = 0.0f;
	ball.dy = 0.0f;
	

	gameOver = false;
	p1win = false;
	p2win = false;
	serve = false;  
}

void Pong::serveBall() {
	
	ball.dx = (rand() % 2 == 0) ? ball.baseSpeed : -ball.baseSpeed;
	ball.dy = (rand() % 3 - 1) * ball.baseSpeed / 2.0f; 
	if (ball.dy == 0) ball.dy = ball.baseSpeed / 2.0f;  
	serve = true;
}
void Pong::init()
{
	paddle1shape.setSize(sf::Vector2f(paddle1.width, paddle1.height));
	paddle1shape.setFillColor(paddle1Color);
	paddle1shape.setPosition(paddle1.x, paddle1.y);

	paddle2shape.setSize(sf::Vector2f(paddle2.width, paddle2.height));
	paddle2shape.setFillColor(paddle2Color);
	paddle2shape.setPosition(paddle2.x, paddle2.y);


	// Create ball shape
	ballCell.setRadius(ball.radius);
	ballCell.setFillColor(ballColor);
	ballCell.setOrigin(ball.radius, ball.radius);
	ballCell.setPosition(ball.x, ball.y);


	// Initialize text objects
	player1NameText.setFont(font);
	player1NameText.setCharacterSize(24);
	player1NameText.setFillColor(paddle1Color);

	player2NameText.setFont(font);
	player2NameText.setCharacterSize(24);
	player2NameText.setFillColor(paddle2Color);

	player1ScoreText.setFont(font);
	player1ScoreText.setCharacterSize(48);
	player1ScoreText.setFillColor(sf::Color::White);

	player2ScoreText.setFont(font);
	player2ScoreText.setCharacterSize(48);
	player2ScoreText.setFillColor(sf::Color::White);

	gameOverText.setFont(font);
	gameOverText.setCharacterSize(60);
	gameOverText.setFillColor(sf::Color::Red);
	gameOverText.setString("GAME OVER");

	winnerText.setFont(font);
	winnerText.setCharacterSize(40);
	winnerText.setFillColor(sf::Color::Yellow);

	serveText.setFont(font);
	serveText.setCharacterSize(30);
	serveText.setFillColor(sf::Color::White);
	serveText.setString("Press SPACE to serve");

	instructionsText.setFont(font);
	instructionsText.setCharacterSize(18);
	instructionsText.setFillColor(sf::Color(200, 200, 200));
	instructionsText.setString("Player 1 (Blue): W/S | Player 2 (Red): I/K | R: Restart | ESC: Menu");

	updateTexts();
}

void Pong:: updateTexts()
{
	player1NameText.setString(player1name);
	player2NameText.setString(player2name);

	player1ScoreText.setString(to_string(paddle1.score));
	player2ScoreText.setString(to_string(paddle2.score));	

	player1NameText.setPosition(100, 20);
	player1ScoreText.setPosition(150, 60);
	player2NameText.setPosition(screenwidth - 200, 20);
	player2ScoreText.setPosition(screenwidth - 150, 60);
	instructionsText.setPosition(50, screenheight - 40);
	centerText(serveText, screenwidth / 2, screenheight / 2 + 50);

}

void Pong::handleEvents()
{
		if (!gameWindow) return;

		sf::Event event;
		while (gameWindow->pollEvent(event)) {
			if (event.type == sf::Event::Closed) {
				gameWindow->close();
			}

			if (event.type == sf::Event::KeyPressed) {
				if (event.key.code == sf::Keyboard::Escape) {
					gameWindow->close(); // This breaks the run() loop and returns to Hub
					return;
				}

				if (event.key.code == sf::Keyboard::R) {
					reset();
					return;
				}

				// Serve ball if game not over and ball not moving
				if (event.key.code == sf::Keyboard::Space) {
					if (!gameOver && !serve) {
						serveBall(); 
					}
				}
			}
		}

		if (!gameOver && serve) {
			// Player 1 (W/S)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && paddle1.y > 0) {
				paddle1.y -= paddle1.speed;
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && paddle1.y + paddle1.height < screenheight) {
				paddle1.y += paddle1.speed;
			}

			// Player 2 (I/K)
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::I) && paddle2.y > 0) {
				paddle2.y -= paddle2.speed;
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::K) && paddle2.y + paddle2.height < screenheight) {
				paddle2.y += paddle2.speed;
			}
		}
	}

void Pong::update() {
	if (!gameWindow || gameOver) return;

	if (!serve) return;  // Ball not moving, wait for serve

	// Move ball
	ball.x += ball.dx;
	ball.y += ball.dy;

	
	checkCollisions();

	// Update shapes
	paddle1shape.setPosition(paddle1.x, paddle1.y);
	paddle2shape.setPosition(paddle2.x, paddle2.y);
	ballCell.setPosition(ball.x, ball.y);

	updateTexts();
}
void Pong::checkCollisions()
{

	if (ball.y - ball.radius <= 0) {
		ball.y = ball.radius; 
		ball.dy = -ball.dy;
	}
	if (ball.y + ball.radius >= screenheight) {
		ball.y = screenheight - ball.radius;
		ball.dy = -ball.dy;
	}

	// Paddle collisions
	// Paddle 1 (left)
	if (ball.x - ball.radius <= paddle1.x + paddle1.width &&
		ball.x + ball.radius >= paddle1.x &&
		ball.y >= paddle1.y &&
		ball.y <= paddle1.y + paddle1.height) {


		float position = (ball.y - paddle1.y) / paddle1.height - 0.5f;
		ball.dx = fabs(ball.dx);
		ball.dy = position * 3.0f;
		ball.dx += 0.5f;
		ball.x = paddle1.x + paddle1.width + ball.radius;
		paddleHitSound.play();
	}

	// Paddle 2 (right)
	if (ball.x + ball.radius >= paddle2.x &&
		ball.x - ball.radius <= paddle2.x + paddle2.width &&
		ball.y >= paddle2.y &&
		ball.y <= paddle2.y + paddle2.height) {

		float position = (ball.y - paddle2.y) / paddle2.height - 0.5f;
		ball.dx = -fabs(ball.dx);
		ball.dy = position * 3.0f;
		ball.dx -= 0.5f;
		ball.x = paddle2.x - ball.radius;
		paddleHitSound.play();
	}


	if (ball.x < 0) {
		paddle2.score++;
		serve = false; 
		ball.x = screenwidth / 2;
		ball.y = screenheight / 2;
		if (paddle2.score >= winScore) gameOver = true;
	}
	else if (ball.x > screenwidth) {
		paddle1.score++;
		serve = false; 
		ball.x = screenwidth / 2;
		ball.y = screenheight / 2;
		if (paddle1.score >= winScore) gameOver = true;
	}
}
	

	void Pong::render() {
		if (!gameWindow) return;

		
		sf::RectangleShape background;
		background.setSize(sf::Vector2f(screenwidth, screenheight));
		background.setFillColor(backgroundColor);
		gameWindow->draw(background);

		
		sf::RectangleShape centerLine(sf::Vector2f(2, screenheight));
		centerLine.setFillColor(sf::Color(100, 100, 100));
		centerLine.setPosition(screenwidth / 2 - 1, 0);
		gameWindow->draw(centerLine);

		
		gameWindow->draw(paddle1shape);
		gameWindow->draw(paddle2shape);
		gameWindow->draw(ballCell);

		drawUI();
	}


	void Pong::drawUI() {
		gameWindow->draw(player1NameText);
		gameWindow->draw(player1ScoreText);
		gameWindow->draw(player2NameText);
		gameWindow->draw(player2ScoreText);
		gameWindow->draw(instructionsText);

		if (!serve && !gameOver) {
			gameWindow->draw(serveText);
		}

		if (gameOver) 
		{
			// 1. Darken background
			sf::RectangleShape overlay(sf::Vector2f(screenwidth, screenheight));
			overlay.setFillColor(sf::Color(0, 0, 0, 150));
			gameWindow->draw(overlay);


			if (p1win) {
				winnerText.setString(string(player1name) + " IS THE CHAMPION!");
			}
			else {
				winnerText.setString(string(player2name) + " IS THE CHAMPION!");
			}


			centerText(gameOverText, screenwidth / 2, screenheight / 2 - 50);
			centerText(winnerText, screenwidth / 2, screenheight / 2 + 20);

			gameWindow->draw(gameOverText);
			gameWindow->draw(winnerText);

			// 4. Instructions
			sf::Text restartText;
			restartText.setFont(font);
			restartText.setCharacterSize(25);
			restartText.setFillColor(sf::Color::White);
			restartText.setString("Press [R] to Rematch  |  [ESC] for Menu");
			centerText(restartText, screenwidth / 2, screenheight / 2 + 100);
			gameWindow->draw(restartText);

			if (!scoreSaved) {
				leaderBoard();
				scoreSaved = true;
				gameOverSound.play();
			}
		}
	}

	// Center text helper
	void Pong::centerText(sf::Text& text, float x, float y) {
		sf::FloatRect textRect = text.getLocalBounds();
		text.setOrigin(textRect.left + textRect.width / 2.0f,
			textRect.top + textRect.height / 2.0f);
		text.setPosition(x, y);
	}

	void Pong::leaderBoard()
	{
		if (gameOver && !scoreSaved)
		{
			ofstream file("score.txt", ios::app);
			file << "Pong: ";
			if (p1win)
			{
				file << player1name << " won with 5 points" << endl;
			}
			else
			{
				file << player2name << " won with 5 points" << endl;

			}
			file.close();

		}
		
	}
