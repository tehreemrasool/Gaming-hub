#pragma once
#include <iostream>
using namespace std;
#include <string>
#include <SFML/Graphics.hpp>

class Leaderboard
{
	static const int maxScores = 10;
	string scores [maxScores];
	int scoresLoaded;

	sf::Color backgroundColor;
	sf::Color nameColor;
	sf::Color scoreColor;

	sf::Font font;
	sf::Text leaderboadh;
	sf::Text scoretext;
	sf::Text nameText;

	sf::RenderWindow* gameWindow;

public:
	Leaderboard();
	void init();
	void run();
	void write();
	void render();
	void centerText(sf::Text& text, float x, float y);
	void saveScore(const char* name, int score);



};
